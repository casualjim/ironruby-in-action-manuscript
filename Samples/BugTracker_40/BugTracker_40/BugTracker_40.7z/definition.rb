
class Machine

    def assign(asignee)
      puts "assigning to #{asignee}"

    end
    def defer
    end
    def close
    end
end
ctxt.statemachine = Machine.new
